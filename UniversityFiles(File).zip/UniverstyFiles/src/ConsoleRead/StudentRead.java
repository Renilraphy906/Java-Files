package ConsoleRead;

import java.util.Scanner;
import Domains.Course;
import Domains.Seminar;
import Domains.Student;

public class StudentRead {
	
	public Student studentDetails()
	{
		int studentid;
		String studentname;
		long phonenumber;
		String emailid;
		Course course = new Course();
		int cid;
		Seminar seminar = new Seminar();
		int sid;
		
		Scanner obj = new Scanner(System.in);
		
		System.out.println("Enter Student ID  :");
		studentid = obj.nextInt();
		
		System.out.println("Enter Name  :");
		studentname = obj.next();
		
		System.out.println("Enter Phone Number  :");
		phonenumber = obj.nextLong();
		
		System.out.println("Enter Email ID  :");
		emailid = obj.next();
		
		System.out.println("Enter Course ID Studying  :");
		cid = obj.nextInt();
		
		System.out.println("Enter Seminar ID  :");
		sid = obj.nextInt();
		
		course.setCourseId(cid);
		seminar.setSeminarno(sid);
		
		Student stu = new Student(studentid, studentname,phonenumber, emailid, course, seminar); 
		return stu;
	}
		
	public StringBuilder convertStudentToSB()
	{
		StudentRead sr = new StudentRead();
		Student stu = sr.studentDetails();
		
		StringBuilder sb = new StringBuilder();
		sb.append(stu.getStudentid());
		sb.append(",");
		sb.append(stu.getStudentname());
		sb.append(",");
		sb.append(stu.getPhonenumber());
		sb.append(",");
		sb.append(stu.getEmailid());
		sb.append(",");
		sb.append(stu.getCourse().getCourseId());
		sb.append(",");
		sb.append(stu.getSeminar().getSeminarno());
		
		System.out.println("Inserted Succesfully!!!");
		return sb;
	}
}
