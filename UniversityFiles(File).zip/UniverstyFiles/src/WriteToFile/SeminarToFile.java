package WriteToFile;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import ConsoleRead.SeminarRead;

public class SeminarToFile {
	
	public void writeInToFile()
	{
		File file = new File("Files/Seminar.txt");
		
		try
		{
			if(!file.exists())
			{
				System.out.println("We have to create new file");
				file.createNewFile();
			}
			SeminarRead ab = new SeminarRead();
			StringBuilder c = ab.convertToStringBuilder(); 
			String s = String.valueOf(c);
		
			FileWriter fwri = new FileWriter(file, true);
			BufferedWriter writer = new BufferedWriter(fwri); 
				
				writer.write(s);
				writer.newLine();
				System.out.println("Inserted");
				writer.close();
			
		} catch(IOException e)
		{
			System.out.println(e);
		}
	}	
}



