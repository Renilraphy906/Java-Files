package Domains;

public class Student {

	private int studentid;
	private String studentname;
	private long phonenumber;
	private String emailid;
	Course course;
	Seminar seminar;
	
	public Student()
	{
		this.studentid = 0;
		this.studentname = null;
		this.phonenumber = 0;
		this.emailid = null;
		this.course = null;
		this.seminar = null;
	}
	public Student(int studentid, String studentname, long phonenumber, String emailid, Course course, Seminar seminar)
	{
		this.studentid = studentid;
		this.studentname = studentname;
		this.phonenumber = phonenumber;
		this.emailid = emailid;
		this.course = course;
		this.seminar = seminar;
	}
	public int getStudentid() {
		return studentid;
	}
	public void setStudentid(int studentid) {
		this.studentid = studentid;
	}
	public String getStudentname() {
		return studentname;
	}
	public void setStudentname(String studentname) {
		this.studentname = studentname;
	}
	public long getPhonenumber() {
		return phonenumber;
	}
	public void setPhonenumber(long phonenumber) {
		this.phonenumber = phonenumber;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public Course getCourse() {
		return course;
	}
	public void setCourse(Course course) {
		this.course = course;
	}
	
	public Seminar getSeminar() {
		return seminar;
	}
	public void setSeminar(Seminar seminar) {
		this.seminar = seminar;
	}
	@Override
	public String toString() {
		return "Student [studentid=" + studentid + ", studentname=" + studentname + ", phonenumber=" + phonenumber
				+ ", emailid=" + emailid + ", course=" + course + ", seminar=" + seminar + "]";
	}
	
	
	
}
