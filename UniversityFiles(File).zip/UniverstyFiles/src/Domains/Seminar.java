package Domains;

public class Seminar {

	private int seminarno;
	private String seminarname;
	
	public Seminar()
	{
		this.seminarno = 0;
		this.seminarname = null;
	}
	
	public Seminar(String seminarname,int seminarno )
	{
		this.seminarno = seminarno;
		this.seminarname = seminarname;
	}
	
		
	public int getSeminarno() {
		return seminarno;
	}

	public void setSeminarno(int seminarno) {
		this.seminarno = seminarno;
	}

	public String getSeminarname() {
		return seminarname;
	}

	public void setSeminarname(String seminarname) {
		this.seminarname = seminarname;
	}

	public String toString()
	{
		return "Seminar [ Seminar Number : "+seminarno+"  , Seminar Name  :"+seminarname+"]";
	}
}
