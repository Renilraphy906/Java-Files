package FileReader;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import Domains.Seminar;

public class FileToSeminar {
	
	public void readFromFile(String path)
	{
		Seminar smr = new Seminar();
		String[] arr = new String[10]; 
				
		try
		{
			BufferedReader br = new BufferedReader(new FileReader(path)); 
			String s; 
			while ((s = br.readLine()) != null)
			{
				arr = s.split(",");
				int a =Integer.valueOf(arr[0]);
				smr.setSeminarno(a);
				
				String b = String.valueOf(arr[1]);
				smr.setSeminarname(b);
				
				System.out.println(smr);
				 
			}
		} catch(IOException e)
		{
			System.out.println(e);
		}
	}
}
