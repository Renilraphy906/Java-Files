package ConsoleRead;

import Domains.Seminar;

import java.util.InputMismatchException;
import java.util.Scanner;

public class SeminarRead {
	
	public Seminar seminarDetails()
	{
	Scanner ab = new Scanner(System.in);
	Seminar obj = null;
	
			System.out.println("Enter the Seminar Number");
			int a = ab.nextInt();
		
			System.out.println("Enter the Seminar Name");
			String s = ab.next();
		
			obj = new Seminar(s,a);
			return obj;
	}
	
	public StringBuilder convertToStringBuilder()
	{
		SeminarRead ab = new SeminarRead();
		Seminar c = ab.seminarDetails();
		
		StringBuilder sss = new StringBuilder();
		
		sss.append(c.getSeminarno());
		sss.append(",");
		sss.append(c.getSeminarname());
	
		System.out.println(sss);
		return sss;
	}
}
