package WriteToFile;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import ConsoleRead.CourseRead;

public class CourseToFile {
	
	public void courseToFileWriting(String path) throws IOException
	{
	
		File file = new File(path);
		
		if(!file.exists())
		{
			file.createNewFile();
		}
		else
		{
			CourseRead cr = new CourseRead();
			
			StringBuilder ss = cr.convertCourseToStringBuilder();
			String s = String.valueOf(ss); 
			
			FileWriter fw = new FileWriter(file,true);
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(s);
			bw.newLine();
			bw.close();
		}				
	}
}
