package FileReader;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

import Domains.*;

public class FileToStudent {

	int n = 0;
	int flag = 0;
	
	String[] arr = new String[10];
	
	Student stu  = new Student();
	Course crs = new Course();
	Seminar smr = new Seminar();
	
	public void readFileToStudent(String path) throws IOException
	{
		File file = new File(path);
		FileReader fr = new FileReader(file);
		
		BufferedReader br = new BufferedReader(fr);
		String s;
		
		while((s = br.readLine()) != null)
		{
			arr = s.split(",");
			int a =Integer.valueOf(arr[0]);
			stu.setStudentid(a);
			
			String b = String.valueOf(arr[1]);
			stu.setStudentname(b);
			
			long c = Long.valueOf(arr[2]);
			stu.setPhonenumber(c);
			
			String d = String.valueOf(arr[3]);
			stu.setEmailid(d);
			
			int e = Integer.valueOf(arr[4]);
			crs.setCourseId(e);
			stu.setCourse(crs);
			
			int f = Integer.valueOf(arr[5]);
			smr.setSeminarno(f);
			stu.setSeminar(smr);

			
			System.out.println(stu);
		}
		fr.close();
		
	}
	
	public int studentList(String path) throws IOException
	{
		this.flag = 0;
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the courseid...");
		int crid = sc.nextInt(), e = 0; 
		
			File file = new File(path);
			FileReader fr = new FileReader(file);
			
			BufferedReader br = new BufferedReader(fr);
			String s;
			
			
			while((s = br.readLine()) != null)
			{	
				
				arr = s.split(",");
					int a =Integer.valueOf(arr[0]);
					stu.setStudentid(a);
					
					String b = String.valueOf(arr[1]);
					stu.setStudentname(b);
					
					long c = Long.valueOf(arr[2]);
					stu.setPhonenumber(c);
					
					String d = String.valueOf(arr[3]);
					stu.setEmailid(d);
					
					e = Integer.valueOf(arr[4]);
					crs.setCourseId(e);
					stu.setCourse(crs);
					
					int f = Integer.valueOf(arr[5]);
					smr.setSeminarno(f);
					stu.setSeminar(smr);
					
					if(e == crid)
					{
						this.flag = 1;
						System.out.println(stu);
					}
					
			}
			
			if(this.flag == 0)
			{
				System.out.println("Invalid Course Id!!!!");
			}
			int f = Integer.valueOf(arr[4]);
			
			fr.close();
			return flag;
	}
}

