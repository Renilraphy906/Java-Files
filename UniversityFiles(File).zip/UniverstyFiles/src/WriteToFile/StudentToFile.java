package WriteToFile;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import ConsoleRead.StudentRead;
import Domains.Student;

public class StudentToFile {
	
	public void writeStudentToFile(String path) throws IOException
	{
		StudentRead sr = new StudentRead();
		StringBuilder sb = sr.convertStudentToSB();
		
		String s = String.valueOf(sb);
		
		File file = new File(path);
	
		if(!file.exists())
		{
			file.createNewFile();
		}
		else
		{
		
			FileWriter fr = new FileWriter(file,true);
			BufferedWriter bw = new BufferedWriter(fr);
			bw.write(s);
			bw.newLine();
			bw.close();
		
		}
	}
	public static void main(String args[]) throws IOException
	{
		StudentToFile sf = new StudentToFile();
		sf.writeStudentToFile("Files/Student.txt");
	}
	
}
