package Domains;

public class Course {
	
	private int  courseid;
	private String coursename;
	private double fees;
	Seminar seminar;
	
	public Course()
	{
		this.courseid = 0;
		this.coursename = null;
		this.fees = 0;
		this.seminar = null;
	}
	
	public Course(int courseid, String coursename, double fees, Seminar seminar)
	{
		this.courseid = courseid;
		this.coursename = coursename;
		this.fees = fees;
		this.seminar = seminar;
	}
	
	public void setCourseId(int courseid)
	{
		this.courseid = courseid;
	}
	
	public int getCourseId()
	{
		return courseid;
	}

	public String getCourseName() {
		return coursename;
	}

	public void setCourseName(String coursename) {
		this.coursename = coursename;
	}

	public double getFees() {
		return fees;
	}

	public void setFees(double fees) {
		this.fees = fees;
	}

	public Seminar getSeminar() {
		return seminar;
	}

	public void setSeminar(Seminar seminarid) {
		this.seminar = seminarid;
	}

	@Override
	public String toString() {
		return "Course [courseid=" + courseid + ", coursename=" + coursename + ", fees=" + fees +", seminar"+seminar+"]";
	}
	
	
	
}
