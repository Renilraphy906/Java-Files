package Main;
import java.io.IOException;
import java.util.Scanner;

import FileReader.FileToCourse;
import FileReader.FileToSeminar;
import FileReader.FileToStudent;
import WriteToFile.CourseToFile;
import WriteToFile.SeminarToFile;
import WriteToFile.StudentToFile;
import ConsoleRead.*;

public class MainClass {
		
	public static void main(String args[]) throws IOException
	{
		try
		{
		
			Menu menu  = new Menu();
			String b = "";
		
			do
			{
				Scanner sca = new Scanner(System.in);
				menu.printTheMenu();
				System.out.println("Do you want to continue (y/n)?");
				b = sca.next();
			}while(b.equals("y"));
			
			if(!b.equals("y"))
			{
				if(b.equals("n"))
				{
					System.out.println("Succesfully Exited!!!");
					System.exit(0);
				}
				else
				{
					System.out.println("You are Exited...Invalid Entry!!!");
					exit(0);
				}
			}

		}
		catch(IOException e)
		{
			System.out.println(e);
		}
			}

	private static void exit(int i) {
		// TODO Auto-generated method stub
		
	}

}
