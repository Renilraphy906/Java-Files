package ConsoleRead;

import java.util.Scanner;
import Domains.Course;
import Domains.Seminar;

public class CourseRead {

	public Course courseDetails()
	{
		int courseid, cd;
		String coursename;
		double fees;
		Seminar seminar = new Seminar();
		
		Scanner obj = new Scanner(System.in);
		
		System.out.println("Enter Course ID   :  ");
		courseid = obj.nextInt();
		
		System.out.println("Enter Course Name   :  ");
		coursename = obj.next();
		
		System.out.println("Enter Fees   :  ");
		fees = obj.nextDouble();
		
		System.out.println("Enter Seminar ID   :  ");
		cd = obj.nextInt();
		seminar.setSeminarno(cd);
		
		Course cr = new Course(courseid,coursename,fees,seminar);
		return cr;
	}
	public StringBuilder convertCourseToStringBuilder()
	{
		CourseRead ab = new CourseRead();
		Course c = ab.courseDetails();
		
		StringBuilder sss = new StringBuilder();
		
		sss.append(c.getCourseId());
		sss.append(",");
		sss.append(c.getCourseName());
		sss.append(",");
		sss.append(c.getFees());
		sss.append(",");
		sss.append(c.getSeminar().getSeminarno());
	
		System.out.println(sss);
		return sss;
	}
}
