package FileReader;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import Domains.Course;
import Domains.Seminar;

public class FileToCourse {

	Course crs = new Course();
	Seminar smr = new Seminar();
	String[] arr = new String[10];
	
	public void readFromCourseFile(String path)
	{
		try
		{
			BufferedReader br = new BufferedReader(new FileReader(path)); 
			String s; 
			while ((s = br.readLine()) != null)
			{
				arr = s.split(",");
				int a =Integer.valueOf(arr[0]);
				crs.setCourseId(a);
				
				String b = String.valueOf(arr[1]);
				crs.setCourseName(b);
				
				double c = Double.valueOf(arr[2]);
				crs.setFees(c);
				
				int e = Integer.valueOf(arr[3]);
				smr.setSeminarno(e);
				crs.setSeminar(smr);
				
				System.out.println(crs);

			}
		} catch(IOException e)
		{
			System.out.println(e);
		}
		

	}

}
