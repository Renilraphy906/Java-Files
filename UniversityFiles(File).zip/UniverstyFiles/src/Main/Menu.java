package Main;

import java.io.IOException;
import java.util.Scanner;

import FileReader.FileToCourse;
import FileReader.FileToSeminar;
import FileReader.FileToStudent;
import WriteToFile.CourseToFile;
import WriteToFile.SeminarToFile;
import WriteToFile.StudentToFile;

public class Menu {

	public void printTheMenu() throws IOException
	{
		Scanner sca = new Scanner(System.in);
		
		SeminarToFile semi = new SeminarToFile();
		FileToSeminar semi1 = new FileToSeminar();
		CourseToFile cs = new CourseToFile();
		FileToCourse cs1 = new FileToCourse();
		StudentToFile sf = new StudentToFile();
		FileToStudent sf1 = new FileToStudent();
		
		System.out.println("Select The Option!!!");
		System.out.println("1. Seminar Topics.");
		System.out.println("2. Add Seminar Topics.");
		System.out.println("3. Course.");
		System.out.println("4. Add Course.");
		System.out.println("5. Student.");
		System.out.println("6. Add Student.");
		System.out.println("7. Search Student.");
		System.out.println("8. Exit.");
		System.out.println();
		System.out.println("Enter the option...");
		
		
		int a = sca.nextInt();
		
		switch(a)
		{
		case 1:semi1.readFromFile("Files/Seminar.txt");
			   break;
		
		case 2:semi.writeInToFile();
			    break;
			    
	
		case 3:cs1.readFromCourseFile("Files/Course.txt");
			   break;
	    
		case 4:cs.courseToFileWriting("Files/Course.txt");
		       break;
		       
		case 5:sf1.readFileToStudent("Files/Student.txt");
		       break;
 
		case 6:sf.writeStudentToFile("Files/Student.txt");
			   break;

		case 7:sf1.studentList("Files/Student.txt");
			   break;

			   
		case 8:System.out.println("Succesfully Exited!!!!");
			   System.exit(0);
			   break;

	    default:System.out.println("Invalid Entry!!!");
	    		break;
		
		}

	}

	private void exit(int i) {
		// TODO Auto-generated method stub
		
	}

}
